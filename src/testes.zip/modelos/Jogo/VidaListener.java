package modelos.Jogo;

public interface VidaListener {
    void vidaAlterada(int novaVida);
    void vidaSelecionada(int novaVida);
}
