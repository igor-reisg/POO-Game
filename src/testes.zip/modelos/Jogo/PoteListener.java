package modelos.Jogo;

public interface PoteListener {
    void adicionarPote(int quantidade);
    void resetarPote();

}
