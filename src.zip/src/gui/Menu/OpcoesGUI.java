package gui.Menu;

public class OpcoesGUI {
}
