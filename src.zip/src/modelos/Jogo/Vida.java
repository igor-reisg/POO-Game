package modelos.Jogo;

public class Vida {
    int vida;

    public Vida(int vida) {
        this.vida = vida;
    }

    public int getVida() {
        return vida;
    }
    public void setVida(int vida) {
        this.vida = vida;
    }
}
