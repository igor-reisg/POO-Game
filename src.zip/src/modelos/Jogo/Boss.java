package modelos.Jogo;

import modelos.Cartas.Coringa;

public class Boss extends Inimigo {
    Coringa coringa;

    public Boss(Coringa coringa){
        this.coringa = coringa;
    }
}
